'use client';

interface Node {
  id: string;
  x: number;
  y: number;
  visited: boolean;
  current: boolean;
}

interface Edge {
  from: string;
  to: string;
}

interface GraphVisualizationProps {
  nodes: Node[];
  edges: Edge[];
}

export default function GraphVisualization({ nodes, edges }: GraphVisualizationProps) {
  const getNodeColor = (node: Node) => {
    if (node.current) return '#fbbf24'; // yellow-400
    if (node.visited) return '#10b981'; // emerald-500
    return '#3b82f6'; // blue-500
  };

  const getNodeById = (id: string) => {
    return nodes.find(node => node.id === id);
  };

  return (
    <div className="bg-gray-800 p-6 rounded-lg">
      <h3 className="text-lg font-semibold text-white mb-4">Graph Visualization</h3>
      
      <div className="relative bg-gray-900 rounded-lg p-4" style={{ height: '400px' }}>
        <svg width="100%" height="100%" className="absolute inset-0">
          {/* Render edges */}
          {edges.map((edge, index) => {
            const fromNode = getNodeById(edge.from);
            const toNode = getNodeById(edge.to);
            
            if (!fromNode || !toNode) return null;
            
            const isActiveEdge = (fromNode.visited || fromNode.current) && 
                               (toNode.visited || toNode.current);
            
            return (
              <line
                key={index}
                x1={fromNode.x}
                y1={fromNode.y}
                x2={toNode.x}
                y2={toNode.y}
                stroke={isActiveEdge ? '#8b5cf6' : '#4b5563'}
                strokeWidth={isActiveEdge ? '3' : '2'}
                className="transition-all duration-300"
              />
            );
          })}
          
          {/* Render nodes */}
          {nodes.map((node) => (
            <g key={node.id} className="transition-all duration-300">
              <circle
                cx={node.x}
                cy={node.y}
                r="20"
                fill={getNodeColor(node)}
                stroke="#1f2937"
                strokeWidth="2"
                className="transition-all duration-300"
              />
              <text
                x={node.x}
                y={node.y}
                textAnchor="middle"
                dominantBaseline="middle"
                fill="white"
                fontSize="14"
                fontWeight="bold"
              >
                {node.id}
              </text>
            </g>
          ))}
        </svg>
      </div>
      
      <div className="mt-4 flex justify-center space-x-6 text-sm">
        <div className="flex items-center space-x-2">
          <div className="w-4 h-4 bg-blue-500 rounded-full"></div>
          <span className="text-gray-300">Unvisited</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-4 h-4 bg-yellow-400 rounded-full"></div>
          <span className="text-gray-300">Current</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-4 h-4 bg-emerald-500 rounded-full"></div>
          <span className="text-gray-300">Visited</span>
        </div>
      </div>
    </div>
  );
}