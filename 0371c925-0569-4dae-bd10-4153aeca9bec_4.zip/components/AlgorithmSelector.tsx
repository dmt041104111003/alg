'use client';

interface Algorithm {
  id: string;
  name: string;
  complexity: string;
}

interface AlgorithmSelectorProps {
  algorithms: Algorithm[];
  selectedAlgorithm: string;
  setSelectedAlgorithm: (id: string) => void;
}

export default function AlgorithmSelector({ 
  algorithms, 
  selectedAlgorithm, 
  setSelectedAlgorithm 
}: AlgorithmSelectorProps) {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold text-white">Select Algorithm</h2>
      <div className="grid md:grid-cols-3 gap-4">
        {algorithms.map((algorithm) => (
          <button
            key={algorithm.id}
            onClick={() => setSelectedAlgorithm(algorithm.id)}
            className={`p-4 rounded-lg border-2 transition-all cursor-pointer whitespace-nowrap ${
              selectedAlgorithm === algorithm.id
                ? 'border-purple-500 bg-purple-500/20 text-white'
                : 'border-gray-600 bg-gray-800 text-gray-300 hover:border-gray-500 hover:bg-gray-700'
            }`}
          >
            <div className="text-left">
              <h3 className="font-semibold text-lg">{algorithm.name}</h3>
              <p className="text-sm opacity-75 mt-1">Time: {algorithm.complexity}</p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}