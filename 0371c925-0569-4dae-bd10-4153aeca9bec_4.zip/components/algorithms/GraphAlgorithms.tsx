
'use client';

import { useState, useEffect, useRef } from 'react';
import AlgorithmSelector from '../AlgorithmSelector';
import GraphVisualization from '../GraphVisualization';
import CodeDisplay from '../CodeDisplay';
import ControlPanel from '../ControlPanel';

interface Node {
  id: string;
  x: number;
  y: number;
  visited: boolean;
  current: boolean;
}

interface Edge {
  from: string;
  to: string;
}

export default function GraphAlgorithms() {
  const [selectedAlgorithm, setSelectedAlgorithm] = useState('dfs');
  const [isPlaying, setIsPlaying] = useState(false);
  const isPlayingRef = useRef(false);
  const [nodes, setNodes] = useState<Node[]>([
    { id: 'A', x: 150, y: 100, visited: false, current: false },
    { id: 'B', x: 100, y: 200, visited: false, current: false },
    { id: 'C', x: 200, y: 200, visited: false, current: false },
    { id: 'D', x: 50, y: 300, visited: false, current: false },
    { id: 'E', x: 150, y: 300, visited: false, current: false },
    { id: 'F', x: 250, y: 300, visited: false, current: false }
  ]);
  
  const [edges] = useState<Edge[]>([
    { from: 'A', to: 'B' },
    { from: 'A', to: 'C' },
    { from: 'B', to: 'D' },
    { from: 'B', to: 'E' },
    { from: 'C', to: 'E' },
    { from: 'C', to: 'F' },
    { from: 'E', to: 'F' }
  ]);

  const algorithms = [
    { id: 'dfs', name: 'Depth-First Search', complexity: 'O(V + E)' },
    { id: 'bfs', name: 'Breadth-First Search', complexity: 'O(V + E)' }
  ];

  const dfsCode = `function dfs(graph, startNode, visited = new Set()) {
  console.log(startNode); // Process current node
  visited.add(startNode);
  
  // Visit all unvisited neighbors
  for (const neighbor of graph[startNode]) {
    if (!visited.has(neighbor)) {
      dfs(graph, neighbor, visited);
    }
  }
}

// Usage
const graph = {
  'A': ['B', 'C'],
  'B': ['A', 'D', 'E'],
  'C': ['A', 'E', 'F'],
  'D': ['B'],
  'E': ['B', 'C', 'F'],
  'F': ['C', 'E']
};

dfs(graph, 'A');`;

  const bfsCode = `function bfs(graph, startNode) {
  const visited = new Set();
  const queue = [startNode];
  
  visited.add(startNode);
  
  while (queue.length > 0) {
    const currentNode = queue.shift();
    console.log(currentNode); // Process current node
    
    // Add all unvisited neighbors to queue
    for (const neighbor of graph[currentNode]) {
      if (!visited.has(neighbor)) {
        visited.add(neighbor);
        queue.push(neighbor);
      }
    }
  }
}

// Usage
const graph = {
  'A': ['B', 'C'],
  'B': ['A', 'D', 'E'],
  'C': ['A', 'E', 'F'],
  'D': ['B'],
  'E': ['B', 'C', 'F'],
  'F': ['C', 'E']
};

bfs(graph, 'A');`;

  const getAlgorithmCode = () => {
    switch (selectedAlgorithm) {
      case 'dfs':
        return dfsCode;
      case 'bfs':
        return bfsCode;
      default:
        return dfsCode;
    }
  };

  const getAdjacencyList = () => {
    const adjacencyList: { [key: string]: string[] } = {};
    
    nodes.forEach(node => {
      adjacencyList[node.id] = [];
    });
    
    edges.forEach(edge => {
      adjacencyList[edge.from].push(edge.to);
      adjacencyList[edge.to].push(edge.from);
    });
    
    return adjacencyList;
  };

  const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

  const reset = () => {
    setIsPlaying(false);
    isPlayingRef.current = false;
    setNodes(nodes.map(node => ({ 
      ...node, 
      visited: false, 
      current: false 
    })));
  };

  const dfsTraversal = async (nodeId: string, visited: Set<string>, adjacencyList: { [key: string]: string[] }) => {
    if (!isPlayingRef.current || visited.has(nodeId)) return;
    
    visited.add(nodeId);
    
    setNodes(prev => prev.map(node => ({
      ...node,
      current: node.id === nodeId,
      visited: visited.has(node.id)
    })));
    
    await sleep(1500);
    
    if (!isPlayingRef.current) return;
    
    for (const neighbor of adjacencyList[nodeId]) {
      if (!visited.has(neighbor) && isPlayingRef.current) {
        await dfsTraversal(neighbor, visited, adjacencyList);
      }
    }
    
    if (isPlayingRef.current) {
      setNodes(prev => prev.map(node => ({
        ...node,
        current: false
      })));
    }
  };

  const bfsTraversal = async () => {
    const visited = new Set<string>();
    const queue = ['A'];
    visited.add('A');
    
    while (queue.length > 0 && isPlayingRef.current) {
      const currentNode = queue.shift()!;
      
      setNodes(prev => prev.map(node => ({
        ...node,
        current: node.id === currentNode,
        visited: visited.has(node.id)
      })));
      
      await sleep(1500);
      
      if (!isPlayingRef.current) break;
      
      const adjacencyList = getAdjacencyList();
      for (const neighbor of adjacencyList[currentNode]) {
        if (!visited.has(neighbor)) {
          visited.add(neighbor);
          queue.push(neighbor);
        }
      }
    }
    
    setNodes(prev => prev.map(node => ({
      ...node,
      current: false
    })));
    
    setIsPlaying(false);
    isPlayingRef.current = false;
  };

  const play = async () => {
    if (isPlaying) return;
    
    setIsPlaying(true);
    isPlayingRef.current = true;
    
    reset();
    await sleep(100);
    
    isPlayingRef.current = true;
    
    if (selectedAlgorithm === 'dfs') {
      const adjacencyList = getAdjacencyList();
      await dfsTraversal('A', new Set(), adjacencyList);
    } else if (selectedAlgorithm === 'bfs') {
      await bfsTraversal();
    }
    
    setIsPlaying(false);
    isPlayingRef.current = false;
  };

  const pause = () => {
    setIsPlaying(false);
    isPlayingRef.current = false;
  };

  useEffect(() => {
    reset();
  }, [selectedAlgorithm]);

  useEffect(() => {
    isPlayingRef.current = isPlaying;
  }, [isPlaying]);

  return (
    <div className="space-y-6">
      <AlgorithmSelector
        algorithms={algorithms}
        selectedAlgorithm={selectedAlgorithm}
        setSelectedAlgorithm={setSelectedAlgorithm}
      />
      
      <div className="grid lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <GraphVisualization
            nodes={nodes}
            edges={edges}
          />
          
          <ControlPanel
            isPlaying={isPlaying}
            onPlay={play}
            onPause={pause}
            onReset={reset}
            hideGenerateArray={true}
          />
        </div>
        
        <CodeDisplay
          code={getAlgorithmCode()}
          language="javascript"
          title={algorithms.find(a => a.id === selectedAlgorithm)?.name || ''}
        />
      </div>
    </div>
  );
}
