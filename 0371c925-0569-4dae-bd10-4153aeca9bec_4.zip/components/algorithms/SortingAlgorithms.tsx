
'use client';

import { useState, useEffect, useRef } from 'react';
import AlgorithmSelector from '../AlgorithmSelector';
import VisualizationArea from '../VisualizationArea';
import CodeDisplay from '../CodeDisplay';
import ControlPanel from '../ControlPanel';

export default function SortingAlgorithms() {
  const [selectedAlgorithm, setSelectedAlgorithm] = useState('bubble');
  const [array, setArray] = useState<number[]>([64, 34, 25, 12, 22, 11, 90]);
  const [isPlaying, setIsPlaying] = useState(false);
  const isPlayingRef = useRef(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [comparingIndices, setComparingIndices] = useState<number[]>([]);
  const [sortedIndices, setSortedIndices] = useState<number[]>([]);

  const algorithms = [
    { id: 'bubble', name: 'Bubble Sort', complexity: 'O(n²)' },
    { id: 'quick', name: 'Quick Sort', complexity: 'O(n log n)' },
    { id: 'merge', name: 'Merge Sort', complexity: 'O(n log n)' }
  ];

  const bubbleSortCode = `function bubbleSort(arr) {
  const n = arr.length;
  for (let i = 0; i < n - 1; i++) {
    for (let j = 0; j < n - i - 1; j++) {
      if (arr[j] > arr[j + 1]) {
        // Swap elements
        [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];
      }
    }
  }
  return arr;
}`;

  const quickSortCode = `function quickSort(arr, low = 0, high = arr.length - 1) {
  if (low < high) {
    const pi = partition(arr, low, high);
    quickSort(arr, low, pi - 1);
    quickSort(arr, pi + 1, high);
  }
}

function partition(arr, low, high) {
  const pivot = arr[high];
  let i = low - 1;
  
  for (let j = low; j < high; j++) {
    if (arr[j] < pivot) {
      i++;
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
  }
  [arr[i + 1], arr[high]] = [arr[high], arr[i + 1]];
  return i + 1;
}`;

  const mergeSortCode = `function mergeSort(arr) {
  if (arr.length <= 1) return arr;
  
  const mid = Math.floor(arr.length / 2);
  const left = mergeSort(arr.slice(0, mid));
  const right = mergeSort(arr.slice(mid));
  
  return merge(left, right);
}

function merge(left, right) {
  const result = [];
  let i = 0, j = 0;
  
  while (i < left.length && j < right.length) {
    if (left[i] <= right[j]) {
      result.push(left[i++]);
    } else {
      result.push(right[j++]);
    }
  }
  
  return result.concat(left.slice(i)).concat(right.slice(j));
}`;

  const getAlgorithmCode = () => {
    switch (selectedAlgorithm) {
      case 'bubble':
        return bubbleSortCode;
      case 'quick':
        return quickSortCode;
      case 'merge':
        return mergeSortCode;
      default:
        return bubbleSortCode;
    }
  };

  const generateRandomArray = () => {
    const newArray = Array.from({ length: 8 }, () => Math.floor(Math.random() * 100) + 1);
    setArray(newArray);
    reset();
  };

  const reset = () => {
    setIsPlaying(false);
    isPlayingRef.current = false;
    setCurrentStep(0);
    setComparingIndices([]);
    setSortedIndices([]);
  };

  const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

  const bubbleSort = async () => {
    const arr = [...array];
    const n = arr.length;
    
    for (let i = 0; i < n - 1 && isPlayingRef.current; i++) {
      for (let j = 0; j < n - i - 1 && isPlayingRef.current; j++) {
        setComparingIndices([j, j + 1]);
        await sleep(800);
        
        if (!isPlayingRef.current) return;
        
        if (arr[j] > arr[j + 1]) {
          [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];
          setArray([...arr]);
        }
      }
      setSortedIndices(prev => [...prev, n - 1 - i]);
    }
    
    if (isPlayingRef.current) {
      setSortedIndices(Array.from({ length: n }, (_, i) => i));
      setComparingIndices([]);
      setIsPlaying(false);
      isPlayingRef.current = false;
    }
  };

  const quickSort = async (arr: number[], low: number = 0, high: number = arr.length - 1, indices: number[] = Array.from({length: arr.length}, (_, i) => i)) => {
    if (low < high && isPlayingRef.current) {
      const pi = await partition(arr, low, high, indices);
      if (isPlayingRef.current) {
        await quickSort(arr, low, pi - 1, indices);
        await quickSort(arr, pi + 1, high, indices);
      }
    }
  };

  const partition = async (arr: number[], low: number, high: number, indices: number[]) => {
    const pivot = arr[high];
    let i = low - 1;
    
    setComparingIndices([high]);
    await sleep(600);
    
    for (let j = low; j < high && isPlayingRef.current; j++) {
      setComparingIndices([j, high]);
      await sleep(600);
      
      if (!isPlayingRef.current) return i + 1;
      
      if (arr[j] < pivot) {
        i++;
        [arr[i], arr[j]] = [arr[j], arr[i]];
        setArray([...arr]);
        await sleep(400);
      }
    }
    
    if (isPlayingRef.current) {
      [arr[i + 1], arr[high]] = [arr[high], arr[i + 1]];
      setArray([...arr]);
      setSortedIndices(prev => [...prev, i + 1]);
      await sleep(600);
    }
    
    return i + 1;
  };

  const mergeSort = async (startArr: number[] = [...array], start: number = 0, end: number = array.length - 1) => {
    if (start >= end || !isPlayingRef.current) return;
    
    const mid = Math.floor((start + end) / 2);
    
    setComparingIndices([start, mid, end]);
    await sleep(800);
    
    if (!isPlayingRef.current) return;
    
    await mergeSort(startArr, start, mid);
    await mergeSort(startArr, mid + 1, end);
    
    if (isPlayingRef.current) {
      await merge(startArr, start, mid, end);
    }
  };

  const merge = async (arr: number[], start: number, mid: number, end: number) => {
    const left = arr.slice(start, mid + 1);
    const right = arr.slice(mid + 1, end + 1);
    
    let i = 0, j = 0, k = start;
    
    while (i < left.length && j < right.length && isPlayingRef.current) {
      setComparingIndices([start + i, mid + 1 + j]);
      await sleep(600);
      
      if (!isPlayingRef.current) return;
      
      if (left[i] <= right[j]) {
        arr[k] = left[i];
        i++;
      } else {
        arr[k] = right[j];
        j++;
      }
      k++;
      setArray([...arr]);
    }
    
    while (i < left.length && isPlayingRef.current) {
      arr[k] = left[i];
      i++;
      k++;
      setArray([...arr]);
      await sleep(400);
    }
    
    while (j < right.length && isPlayingRef.current) {
      arr[k] = right[j];
      j++;
      k++;
      setArray([...arr]);
      await sleep(400);
    }
    
    if (isPlayingRef.current && start === 0 && end === array.length - 1) {
      setSortedIndices(Array.from({ length: array.length }, (_, i) => i));
    }
  };

  const play = async () => {
    if (isPlaying) return;
    
    setIsPlaying(true);
    isPlayingRef.current = true;
    setSortedIndices([]);
    setComparingIndices([]);
    
    if (selectedAlgorithm === 'bubble') {
      await bubbleSort();
    } else if (selectedAlgorithm === 'quick') {
      const arr = [...array];
      await quickSort(arr);
      if (isPlayingRef.current) {
        setSortedIndices(Array.from({ length: array.length }, (_, i) => i));
        setComparingIndices([]);
      }
    } else if (selectedAlgorithm === 'merge') {
      await mergeSort();
      if (isPlayingRef.current) {
        setComparingIndices([]);
      }
    }
    
    setIsPlaying(false);
    isPlayingRef.current = false;
  };

  const pause = () => {
    setIsPlaying(false);
    isPlayingRef.current = false;
  };

  useEffect(() => {
    reset();
  }, [selectedAlgorithm]);

  useEffect(() => {
    isPlayingRef.current = isPlaying;
  }, [isPlaying]);

  return (
    <div className="space-y-6">
      <AlgorithmSelector
        algorithms={algorithms}
        selectedAlgorithm={selectedAlgorithm}
        setSelectedAlgorithm={setSelectedAlgorithm}
      />
      
      <div className="grid lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <VisualizationArea
            array={array}
            comparingIndices={comparingIndices}
            sortedIndices={sortedIndices}
            type="sorting"
          />
          
          <ControlPanel
            isPlaying={isPlaying}
            onPlay={play}
            onPause={pause}
            onReset={reset}
            onGenerateArray={generateRandomArray}
          />
        </div>
        
        <CodeDisplay
          code={getAlgorithmCode()}
          language="javascript"
          title={algorithms.find(a => a.id === selectedAlgorithm)?.name || ''}
        />
      </div>
    </div>
  );
}
