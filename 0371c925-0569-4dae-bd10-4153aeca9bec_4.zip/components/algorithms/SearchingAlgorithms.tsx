
'use client';

import { useState, useEffect, useRef } from 'react';
import AlgorithmSelector from '../AlgorithmSelector';
import VisualizationArea from '../VisualizationArea';
import CodeDisplay from '../CodeDisplay';
import ControlPanel from '../ControlPanel';

export default function SearchingAlgorithms() {
  const [selectedAlgorithm, setSelectedAlgorithm] = useState('binary');
  const [array, setArray] = useState<number[]>([2, 5, 8, 12, 16, 23, 38, 45, 56, 67, 78]);
  const [target, setTarget] = useState(23);
  const [isPlaying, setIsPlaying] = useState(false);
  const isPlayingRef = useRef(false);
  const [currentIndices, setCurrentIndices] = useState<number[]>([]);
  const [foundIndex, setFoundIndex] = useState<number>(-1);
  const [searchBounds, setSearchBounds] = useState<{ left: number; right: number }>({ left: 0, right: 10 });

  const algorithms = [
    { id: 'binary', name: 'Binary Search', complexity: 'O(log n)' },
    { id: 'linear', name: 'Linear Search', complexity: 'O(n)' }
  ];

  const binarySearchCode = `function binarySearch(arr, target) {
  let left = 0;
  let right = arr.length - 1;
  
  while (left <= right) {
    const mid = Math.floor((left + right) / 2);
    
    if (arr[mid] === target) {
      return mid; // Found target
    } else if (arr[mid] < target) {
      left = mid + 1; // Search right half
    } else {
      right = mid - 1; // Search left half
    }
  }
  
  return -1; // Target not found
}`;

  const linearSearchCode = `function linearSearch(arr, target) {
  for (let i = 0; i < arr.length; i++) {
    if (arr[i] === target) {
      return i; // Found target
    }
  }
  return -1; // Target not found
}`;

  const getAlgorithmCode = () => {
    switch (selectedAlgorithm) {
      case 'binary':
        return binarySearchCode;
      case 'linear':
        return linearSearchCode;
      default:
        return binarySearchCode;
    }
  };

  const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

  const reset = () => {
    setIsPlaying(false);
    isPlayingRef.current = false;
    setCurrentIndices([]);
    setFoundIndex(-1);
    setSearchBounds({ left: 0, right: array.length - 1 });
  };

  const binarySearch = async () => {
    let left = 0;
    let right = array.length - 1;
    
    while (left <= right && isPlayingRef.current) {
      const mid = Math.floor((left + right) / 2);
      setCurrentIndices([mid]);
      setSearchBounds({ left, right });
      
      await sleep(1200);
      
      if (!isPlayingRef.current) return;
      
      if (array[mid] === target) {
        setFoundIndex(mid);
        setCurrentIndices([]);
        setIsPlaying(false);
        isPlayingRef.current = false;
        return;
      } else if (array[mid] < target) {
        left = mid + 1;
      } else {
        right = mid - 1;
      }
    }
    
    setCurrentIndices([]);
    setIsPlaying(false);
    isPlayingRef.current = false;
  };

  const linearSearch = async () => {
    for (let i = 0; i < array.length && isPlayingRef.current; i++) {
      setCurrentIndices([i]);
      await sleep(800);
      
      if (!isPlayingRef.current) return;
      
      if (array[i] === target) {
        setFoundIndex(i);
        setCurrentIndices([]);
        setIsPlaying(false);
        isPlayingRef.current = false;
        return;
      }
    }
    
    setCurrentIndices([]);
    setIsPlaying(false);
    isPlayingRef.current = false;
  };

  const play = async () => {
    if (isPlaying) return;
    
    setIsPlaying(true);
    isPlayingRef.current = true;
    setFoundIndex(-1);
    setCurrentIndices([]);
    
    if (selectedAlgorithm === 'binary') {
      await binarySearch();
    } else if (selectedAlgorithm === 'linear') {
      await linearSearch();
    }
  };

  const pause = () => {
    setIsPlaying(false);
    isPlayingRef.current = false;
  };

  const generateRandomArray = () => {
    const newArray = Array.from({ length: 10 }, (_, i) => (i + 1) * 5 + Math.floor(Math.random() * 4));
    newArray.sort((a, b) => a - b);
    setArray(newArray);
    setTarget(newArray[Math.floor(Math.random() * newArray.length)]);
    reset();
  };

  useEffect(() => {
    reset();
  }, [selectedAlgorithm, target]);

  useEffect(() => {
    isPlayingRef.current = isPlaying;
  }, [isPlaying]);

  return (
    <div className="space-y-6">
      <AlgorithmSelector
        algorithms={algorithms}
        selectedAlgorithm={selectedAlgorithm}
        setSelectedAlgorithm={setSelectedAlgorithm}
      />
      
      <div className="bg-gray-800 p-4 rounded-lg">
        <div className="flex items-center space-x-4">
          <label className="text-gray-300">Target Value:</label>
          <input
            type="number"
            value={target}
            onChange={(e) => setTarget(Number(e.target.value))}
            className="bg-gray-700 text-white px-3 py-1 rounded border border-gray-600 focus:border-purple-500 outline-none text-sm"
          />
        </div>
      </div>
      
      <div className="grid lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <VisualizationArea
            array={array}
            comparingIndices={currentIndices}
            sortedIndices={foundIndex !== -1 ? [foundIndex] : []}
            type="searching"
            target={target}
            searchBounds={searchBounds}
          />
          
          <ControlPanel
            isPlaying={isPlaying}
            onPlay={play}
            onPause={pause}
            onReset={reset}
            onGenerateArray={generateRandomArray}
          />
        </div>
        
        <CodeDisplay
          code={getAlgorithmCode()}
          language="javascript"
          title={algorithms.find(a => a.id === selectedAlgorithm)?.name || ''}
        />
      </div>
    </div>
  );
}
